//
//  CAppDelegate.h
//  BonjourIOS
//
//  Created by Boobalan Munusamy on 5/6/14.
//  Copyright (c) 2014 greateindialcub. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CAppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end
